package ytGameTutorial;

public enum ID {
	Player(),
	BasicEnemy(),
	FastEnemy(),
	SmartEnemy(),
	BossEnemy(),
	MenuPart(),
	HardEnemy(),
	Trail()
}
