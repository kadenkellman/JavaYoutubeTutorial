package ytGameTutorial;

import java.util.Random;

public class Spawn {
	private Handler handler;
	private HUD hud;
	private int scoreKeep;
	private Random r = new Random();
	private Game game;
	
	public Spawn(Handler handler, HUD hud, Game game) {
		this.handler = handler;
		this.hud = hud;
		this.game = game;
	}
	
	public void tick() {
		scoreKeep++;
		
		if (scoreKeep >= 250) {
			scoreKeep = 0;
			hud.setLevel(hud.getLevel()+1);
			
			if (game.diff == 0) {
				if(hud.getLevel() % 5 == 0) {
					handler.clearEnemies();
					handler.addObject(new EnemyBoss(r.nextInt(Game.WIDTH/2), r.nextInt(Game.HEIGHT/2), ID.BossEnemy, handler));
				}
				if(hud.getLevel() == 2) {
					handler.addObject(new FastEnemy(r.nextInt(Game.WIDTH), r.nextInt(Game.HEIGHT), ID.FastEnemy, handler));
				}
				else if(hud.getLevel() == 3) {
					handler.addObject(new SmartEnemy(r.nextInt(Game.WIDTH), r.nextInt(Game.HEIGHT), ID.SmartEnemy, handler));
				}
			} else if (game.diff == 1) {
				if(hud.getLevel() % 5 == 0) {
					handler.clearEnemies();
					handler.addObject(new EnemyBoss(r.nextInt(Game.WIDTH/2), r.nextInt(Game.HEIGHT/2), ID.BossEnemy, handler));
				}
				
				if(hud.getLevel() == 2) {
					handler.addObject(new FastEnemy(r.nextInt(Game.WIDTH), r.nextInt(Game.HEIGHT), ID.FastEnemy, handler));
				}
				else if(hud.getLevel() == 3) {
					handler.addObject(new HardEnemy(r.nextInt(Game.WIDTH), r.nextInt(Game.HEIGHT), ID.HardEnemy, handler));
				}
			} else if (game.diff == 2) {
				if(hud.getLevel() % 5 == 0) {
					handler.clearEnemies();
					handler.addObject(new EnemyBoss(r.nextInt(Game.WIDTH/2), r.nextInt(Game.HEIGHT/2), ID.BossEnemy, handler));
				}
				
				if(hud.getLevel() == 2) {
					handler.addObject(new FastEnemy(r.nextInt(Game.WIDTH), r.nextInt(Game.HEIGHT), ID.FastEnemy, handler));
				}
				else if(hud.getLevel() == 3) {
					handler.addObject(new SmartEnemy(r.nextInt(Game.WIDTH), r.nextInt(Game.HEIGHT), ID.SmartEnemy, handler));
					handler.addObject(new HardEnemy(r.nextInt(Game.WIDTH), r.nextInt(Game.HEIGHT), ID.HardEnemy, handler));
				}
			}
			
			
			
			
		}
	}
	
}
