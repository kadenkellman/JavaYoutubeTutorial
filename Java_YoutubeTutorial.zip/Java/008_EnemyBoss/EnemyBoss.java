package ytGameTutorial;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Rectangle;
import java.util.Random;

public class EnemyBoss extends GameObject {

	private Handler handler;
	private int width = 64;
	private int height = 64;
	private int timer = 100;
	private int timer2 = 50;
	private Random r = new Random();
	public EnemyBoss(int x, int y, ID id, Handler handler) {
		super(x, y, id);
		velX = 0;
		velY = 1;
		this.handler = handler;
	}

	public Rectangle getBounds() {
		return new Rectangle((int)x, (int)y, width, height);
	}
	
	public void tick() {
		x += velX;
		y += velY;
		if (timer <= 0)
			velY = 0;
		else 
			timer--;
		
		if (timer <= 0)
			timer2--;
		if (timer2<=0) {
			if(velX == 0) {
				velX = 3;
				int spawn = 1;
				spawn++;
				if (spawn <= 10) handler.addObject(new EnemyBossBullet((int) x + 48, (int) y + 48, ID.BasicEnemy, handler));
			}
		}
			
		
		if (x <=0 || x > Game.WIDTH - 32) {
			velX *= -1;
		}/*
		if (y <=0 || y > Game.HEIGHT - 32) {
			velY *= -1;
		}
		*/
		
		handler.addObject(new Trail((int)x, (int)y, ID.Trail, Color.red, width, height, 0.2f, handler));
	}

	public void render(Graphics g) {
		
		g.setColor(Color.red);
		g.fillRect((int)x, (int)y, width, height);
	}

}
