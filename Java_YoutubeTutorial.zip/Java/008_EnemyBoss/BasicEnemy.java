package ytGameTutorial;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Rectangle;

public class BasicEnemy extends GameObject {
	private Handler handler;
	private int width = 16;
	private int height = 16;
	
	public BasicEnemy(int x, int y, ID id, Handler handler) {
		super(x, y, id);
		velX = 5;
		velY = 5;
		this.handler = handler;
	}

	public Rectangle getBounds() {
		return new Rectangle((int)x, (int)y, width, height);
	}
	
	public void tick() {
		x += velX;
		y += velY;
		
		if (x <=0 || x > Game.WIDTH - 32) {
			velX *= -1;
		}
		if (y <=0 || y > Game.HEIGHT - 32) {
			velY *= -1;
		}
		handler.addObject(new Trail((int)x, (int)y, ID.Trail, Color.red, width, height, 0.02f, handler));
	}

	public void render(Graphics g) {
		
		g.setColor(Color.red);
		g.fillRect((int)x, (int)y, 16, 16);
	}
}
