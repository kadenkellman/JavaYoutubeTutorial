package ytGameTutorial;

public enum ID {
	Player(),
	Enemy()
}
