package ytGameTutorial;

public enum ID {
	Player(),
	BasicEnemy(),
	Trail()
}
