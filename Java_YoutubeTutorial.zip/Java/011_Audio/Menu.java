package ytGameTutorial;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.Random;

import ytGameTutorial.Game.STATE;

public class Menu extends MouseAdapter {
	private Game game;
	private Handler handler;
	private Random r = new Random();
	private HUD hud;
	
	public Menu (Game game, Handler handler, HUD hud) {
		this.game = game;
		this.handler = handler;
		this.hud = hud;
	}
	
	public void mousePressed(MouseEvent e) {
		int mx = e.getX();
		int my = e.getY();
		if (game.gameState == STATE.Menu) {
			
			if (mouseOver(mx, my, 450, 150, 250, 64)) {
			game.gameState = STATE.Game;
			handler.addObject(new Player(r.nextInt(Game.WIDTH/2-32), r.nextInt(Game.HEIGHT/2-32), ID.Player,  handler));
			handler.clearEnemies();
			handler.addObject(new BasicEnemy(r.nextInt(Game.WIDTH/2-32), r.nextInt(Game.HEIGHT/2-32), ID.BasicEnemy,  handler));
			//AudioPlayer.getMusic("ahoy").play();
			} else if (mouseOver(mx, my, 450, 300, 250, 64)) {
			game.gameState = STATE.Help;
			} else if (mouseOver(mx, my, 450, 450, 250, 64)) {
			game.gameState = STATE.Store;
			} 
		} else if (game.gameState == STATE.End) {
			if (mouseOver(mx, my, 465, 450, 250, 64)) {
			game.gameState = STATE.Game;
			handler.addObject(new Player(r.nextInt(Game.WIDTH/2-32), r.nextInt(Game.HEIGHT/2-32), ID.Player,  handler));
			handler.clearEnemies();
			handler.addObject(new BasicEnemy(r.nextInt(Game.WIDTH/2-32), r.nextInt(Game.HEIGHT/2-32), ID.BasicEnemy,  handler));
			hud.setLevel(1);
			hud.setScore(0);
			}
		}
	}
	
	public void mouseReleased(MouseEvent e) {
		
	}
	
	private boolean mouseOver(int mx, int my, int x, int y, int width, int height) {
		if (mx > x && mx < x + width) {
			if (my > y && my < y + height)
				return true;
			else
				return false;
		}
		else
			return false;
	}
	
	public void tick() {
		
	}
	
	public void render(Graphics g) {
		if (game.gameState == STATE.Menu) {
			Font f = new Font("arial", 1, 50);
			Font f2 = new Font("arial", 1, 20);
			g.setFont(f);
			g.setColor(Color.white);
			g.drawString("Survive", 485, 85);
			g.drawString("Play", 520, 200);
			g.drawString("Help", 520, 350);
			g.drawString("Store", 520, 500);
			g.setColor(Color.white);
			g.drawRect(450, 150, 250, 64);
			g.setColor(Color.white);
			g.drawRect(450, 300, 250, 64);
			g.setColor(Color.white);
			g.drawRect(450, 450, 250, 64);
			g.setFont(f2);
			g.drawString("Press ESC to quit", 10, 675);
		} else if (game.gameState == STATE.Help){
			Font f = new Font("arial", 1, 50);
			Font f2 = new Font("arial", 1, 20);
			g.setFont(f);
			g.setColor(Color.white);
			g.drawString("Use WASD to dodge enemies.", 300, 350);
			g.setFont(f2);
			g.drawString("Press M for menu", 10, 675);
		} else if (game.gameState == STATE.Store){
			Font f = new Font("arial", 1, 50);
			Font f2 = new Font("arial", 1, 20);
			g.setFont(f);
			g.setColor(Color.white);
			g.drawString("Store", 525, 50);
			g.setFont(f2);
			g.drawString("Press M for menu", 10, 675);
		} else if (game.gameState == STATE.End){
			Font f = new Font("arial", 1, 50);
			Font f2 = new Font("arial", 1, 20);
			g.setFont(f);
			g.setColor(Color.white);
			g.drawString("DED", 525, 200);
			g.setFont(f2);
			g.drawString("Score: " + hud.getScore(), 525, 250);
			g.drawString("Level:  " + hud.getLevel(), 525, 300);
			g.setFont(f);
			g.drawString("Try Again", 475, 500);
			g.setColor(Color.white);
			g.drawRect(465, 450, 250, 64);
			g.setFont(f2);
			g.drawString("ESC: Quit / " + "M: Menu", 10, 675);
		}
	}
}
