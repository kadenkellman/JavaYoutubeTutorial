package ytGameTutorial;

public enum ID {
	Player(),
	BasicEnemy(),
	FastEnemy(),
	Trail()
}
