package ytGameTutorial;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Rectangle;
import java.awt.image.BufferedImage;

public class BasicEnemy extends GameObject {
	private Handler handler;
	private BufferedImage enemyImage;
	private int width = 16;
	private int height = 16;
	
	public BasicEnemy(int x, int y, ID id, Handler handler) {
		super(x, y, id);
		velX = 5;
		velY = 5;
		this.handler = handler;
//		Spritesheet ss = new Spritesheet(Game.spritesheet);
//		enemyImage = ss.grabImage(2, 1, 16, 16)
	}

	public Rectangle getBounds() {
		return new Rectangle((int)x, (int)y, width, height);
	}
	
	public void tick() {
		x += velX;
		y += velY;
		
		if (x <=0 || x > Game.WIDTH - 32) {
			velX *= -1;
		}
		if (y <=0 || y > Game.HEIGHT - 32) {
			velY *= -1;
		}
		handler.addObject(new Trail((int)x, (int)y, ID.Trail, Color.red, width, height, 0.02f, handler));
	}

	public void render(Graphics g) {
		g.setColor(Color.red);
		g.fillRect((int)x, (int)y, 16, 16);
		//g.drawRect(enemyImage, (int) x, (int) y, null);
	}
}
